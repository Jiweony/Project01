package com.example.krpizzaPrj.dto;

public class AdminRegisterDto {

    private String adminId;
    private String adminPw;
    private String adminSt;

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public String getAdminPw() {
        return adminPw;
    }

    public void setAdminPw(String adminPw) {
        this.adminPw = adminPw;
    }

    public String getAdminSt() {
        return adminSt;
    }

    public void setAdminSt(String adminSt) {
        this.adminSt = adminSt;
    }
}
